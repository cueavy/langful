"""
# langful

---

Help developers to localize

---

帮助开发者进行本地化

---

Github: https://github.com/cueavyqwp/langful

Issues: https://github.com/cueavyqwp/langful/issues

"""
import warnings
import locale
import json
import os

from langful.main import *

warnings.filterwarnings("ignore",category=DeprecationWarning)