"""
# langful

Help to localization

# About

github: https://github.com/cueavy/langful

pypi: https://pypi.org/project/langful
"""

from .lang import *
