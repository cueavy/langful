"""
# langful

provides internationalization for python

"""

from .lang import *
